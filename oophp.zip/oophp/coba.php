<?php 

class Coba {

}



$a = new Coba();
$b = new Coba();
$c = new Coba();

var_dump($a);
var_dump($b);
var_dump($c);